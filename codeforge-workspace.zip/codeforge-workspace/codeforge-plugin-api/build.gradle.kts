﻿plugins {
    id("java-library")
}

version = property("plugin_api_version") as String
group = "com.sohonet"
